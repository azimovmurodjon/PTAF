# FNB-PTAF Diagram

please generate complete Framework Architecture Diagram Title Called FNB-PTAF
make sure to separate pom.xml and .feature make clean diagram that includes all part of process optimize properly and clean the lines and use unique icons make it colorful gridlocking for presentation
Code snippet

classDiagram
    direction TB

    subgraph "1. Test Specification & Execution"
        direction LR
        Feature_Files["<b>*.feature</b><br>(UI, API, DB Tests)"]
        pom_xml["<b>pom.xml</b><br>(Maven Configuration)"]
        TestRunner["TestRunner<br>(UI, API, DB)"]
        ParallelRun["ParallelRun<br>(UI)"]
    end

    subgraph "2. Glue Code (Step Definitions)"
        direction LR
        UiSteps["UI Steps<br>(Page & Frame)"]
        ApiSteps["API Steps"]
        DatabaseSteps["Database Steps"]
    end

    subgraph "3. Business Logic Abstractions"
        direction LR
        PageMethods["Page/Frame Methods<br>(Page Object Model)"]
        ApiMethods["API Methods<br>(Service Layer)"]
        DatabaseMethods["Database Methods<br>(Data Access Layer)"]
    end

    subgraph "4. Core Action Implementation"
        direction LR
        subgraph "UI Core"
            ElementActionImpl
            ElementAction["<<interface>><br>ElementAction"]
        end
        subgraph "API Core"
            ApiActionImpl
            ApiAction["<<interface>><br>ApiAction"]
        end
        subgraph "Database Core"
            DatabaseActionImpl
            DatabaseAction["<<interface>><br>DatabaseAction"]
        end
    end

    subgraph "5. Low-Level Helpers & Performers"
        direction LR
        subgraph "UI Helpers"
            ActionPerformer
            LocatorHandler
        end
        subgraph "API Helpers"
            ApiActionPerformer
            ApiResponseWrapper
        end
        subgraph "Database Helpers"
            DatabaseActionPerformer
        end
    end
    
    subgraph "6. Framework Utilities & Services"
        direction LR
        Hooks
        BrowserFactory
        ApiRequestHandler
        DatabaseHandler
        ConfigurationProperties
        ScenarioUtil
        ExcelUtil["ExcelReader / Writer"]
        YamlReader
    end

    subgraph "7. Data Sources"
        direction LR
        YAML_Files["<b>*.yml</b><br>(config, elements, api, queries)"]
        Excel_File["<b>*.xlsx</b><br>(Test Data)"]
    end

    subgraph "8. Reporting"
        direction LR
        ReportingEngine["Reporting Engine<br>(e.g., ExtentReports)"]
        HtmlReport["<b>HTML Report</b>"]
        PdfReport["<b>PDF Report</b>"]
        Screenshots
    end

    %% --- Relationships ---

    %% Execution Flow (1 -> 2 -> 3 -> 4)
    pom_xml --> TestRunner & ParallelRun : configures & runs
    Feature_Files -- defines tests for --> TestRunner & ParallelRun
    TestRunner & ParallelRun -- glues to --> UiSteps & ApiSteps & DatabaseSteps
    UiSteps --> PageMethods : uses
    ApiSteps --> ApiMethods : uses
    DatabaseSteps --> DatabaseMethods : uses
    PageMethods --> ElementActionImpl : delegates to
    ApiMethods --> ApiActionImpl : delegates to
    DatabaseMethods --> DatabaseActionImpl : delegates to

    %% Core Implementation (4 -> 5)
    ElementAction <|.. ElementActionImpl : implements
    ApiAction <|.. ApiActionImpl : implements
    DatabaseAction <|.. DatabaseActionImpl : implements
    ElementActionImpl --> ActionPerformer & LocatorHandler : uses
    ApiActionImpl --> ApiActionPerformer & ApiRequestHandler : uses
    DatabaseActionImpl --> DatabaseActionPerformer & DatabaseHandler : uses
    ApiActionPerformer --> ApiResponseWrapper : creates

    %% Utilities & Data Flow (6 & 7)
    Hooks --> BrowserFactory & ApiRequestHandler & DatabaseHandler : manages lifecycle
    Hooks --> ScenarioUtil : uses for reporting
    TestRunner & ParallelRun --> Hooks : invokes
    ConfigurationProperties & LocatorHandler & ApiActionImpl --> YamlReader : uses
    YamlReader --> YAML_Files : reads
    ExcelUtil --> Excel_File : reads/writes
    BrowserFactory & ApiRequestHandler & DatabaseHandler --> ConfigurationProperties : reads config

    %% Reporting Flow (8)
    Hooks --> ReportingEngine : initializes & finalizes
    ScenarioUtil --> Screenshots : captures
    Screenshots -- attached to --> ReportingEngine
    ReportingEngine -- generates --> HtmlReport & PdfReport
Architectural Layers Explained
This framework follows a well-defined, multi-layered architecture that promotes the Separation of Concerns. This design makes the framework maintainable, scalable, and easy to use.

1. Test Specification & Execution
This is the entry point of the framework, defining what to test and how to run it.

pom.xml: The Maven project file. It manages all dependencies (Playwright, Cucumber, TestNG), plugins, and build profiles. It configures the Surefire plugin to trigger the test runners.

*.feature Files: Human-readable test scenarios written in Gherkin syntax (Given-When-Then). These files serve as living documentation, bridging the gap between technical and non-technical team members.

TestRunner / ParallelRun: JUnit or TestNG classes that execute the tests. They use @CucumberOptions to link the .feature files to the step definition "glue code" and activate reporting plugins.

2. Glue Code (Step Definitions)
This layer acts as a bridge, translating the plain-text Gherkin steps into Java method calls.

UISteps, ApiSteps, DatabaseSteps: These classes contain methods annotated with @Given, @When, @Then. Their sole purpose is to parse arguments from the feature file steps and delegate the actual work to the business logic abstraction layer.

3. Business Logic Abstractions
This layer provides a readable, reusable API that represents the business logic of the application under test. It hides the implementation details from the step definitions.

PageMethods: Implements the Page Object Model (POM). Each class represents a page or a major UI component, providing business-centric methods like loginWithValidCredentials(). This localizes UI changes, enhancing maintainability.

ApiMethods: Acts as a service layer for API interactions, offering methods like createNewUser() or getProductDetails().

DatabaseMethods: Acts as a data access layer, providing methods like isUserRecordPresentInDB() to abstract SQL queries.

4. Core Action Implementation
This is the framework's engine room, where the high-level business commands are translated into concrete technical actions.

ElementActionImpl (UI): The primary implementation for all UI interactions (click, type, select). It orchestrates the use of lower-level helpers to find elements and perform actions.

ApiActionImpl (API): Manages the construction and execution of API requests. It uses ThreadLocal variables to build a request (headers, body) step-by-step before sending it.

DatabaseActionImpl (DB): Orchestrates database operations, managing connections and executing queries.

5. Low-Level Helpers & Performers
These are specialized utility classes that directly interact with external libraries like Playwright or JDBC. This isolation makes it easier to swap technologies in the future.

UI Helpers: ActionPerformer directly wraps Playwright commands (e.g., locator.click()), while LocatorHandler reads locator strings from YAML files to create Playwright Locator objects.

API Helpers: ApiActionPerformer sends the final HTTP request, and ApiResponseWrapper standardizes the response object.

Database Helpers: DatabaseActionPerformer executes SQL queries using PreparedStatement to prevent SQL injection.

6. Framework Utilities & Services
These are the cross-cutting services that support the entire framework.

Hooks: Manages the test lifecycle using @Before and @After annotations. It is responsible for initializing and tearing down drivers, database connections, API contexts, and the reporting engine for each scenario.

BrowserFactory, ApiRequestHandler, DatabaseHandler: These factories manage the lifecycle of their respective resources. Their use of ThreadLocal is crucial for safe parallel execution, ensuring each test thread has its own isolated instance.

ConfigurationProperties: Provides a global, static, and convenient interface for accessing configuration data. It uses the YamlReader but abstracts it away, offering specific methods like getBrowser() and getBaseUrl() so that other services can retrieve settings without needing to know the underlying data source or key names.

YamlReader / ExcelUtil: Utilities for reading data from external files (.yml, .xlsx), separating test data from test logic.

ScenarioUtil: A reporting utility, primarily used to capture and attach screenshots to the test report on failure.

7. Data Sources
Externalizing data and configuration makes the framework flexible and easy to update without changing code.

YAML Files (*.yml): Used for storing environment configurations, UI element locators, API request templates, and SQL queries.

Excel Files (*.xlsx): Used for data-driven testing, where a single test scenario is executed multiple times with different sets of data from a spreadsheet.

8. Reporting 📊
This layer is responsible for generating comprehensive and understandable test execution reports.

Reporting Engine: A third-party library like ExtentReports or Allure that aggregates test results. It is initialized in the Hooks class before the test suite runs and finalized after all tests are complete.

Screenshots: Captured by ScenarioUtil upon test failure and embedded directly into the report, providing immediate visual context for debugging.

HTML Report / PDF Report: The final output artifacts. The HTML report is interactive, allowing users to filter results and view detailed steps, logs, and screenshots. A PDF report can be generated for distribution and archiving.

