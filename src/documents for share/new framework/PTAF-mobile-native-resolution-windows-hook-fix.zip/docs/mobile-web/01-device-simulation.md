# Mobile Web Device Simulation

Mobile web simulation uses the existing Playwright browser flow. The only change is the `browser` value in `src/test/resources/config/config.yml`.

## 1. Configure A Mobile Device

Change:

```yaml
browser: "chrome"
```

To a supported mobile profile:

```yaml
browser: "iPhone 17 Pro Max Safari"
```

The framework will automatically:

1. Find the device profile in `src/test/resources/config/mobile-devices.yml`.
2. Launch the correct Playwright browser engine.
3. Apply viewport, screen size, device scale factor, touch, mobile mode, and user agent.
4. Run the same Cucumber web steps you already use.

## 2. Supported Profile Names

iOS phones:

```text
iPhone 17 Pro Max Safari
iPhone 17 Pro Safari
iPhone 17 Safari
iPhone 17e Safari
iPhone 16 Pro Max Safari
iPhone 16 Pro Safari
```

iOS tablets:

```text
iPad Pro 13 Safari
iPad Pro 11 Safari
iPad Air 13 Safari
iPad Air 11 Safari
iPad mini Safari
```

Android phones:

```text
Pixel 10 Pro XL Chrome
Pixel 10 Pro Chrome
Galaxy S26 Ultra Chrome
Galaxy S26 Plus Chrome
Galaxy Z Fold Chrome
```

Android tablets:

```text
Galaxy Tab S11 Ultra Chrome
Galaxy Tab S11 Chrome
Pixel Tablet Chrome
Galaxy Tab S10 Ultra Chrome
Galaxy Tab S10 Plus Chrome
```

## 3. Example Test

See:

```text
src/test/resources/features/mobile_web/mobile_web_smoke.feature
```

Run it with:

```bash
mvn -Dtest=MobileWebTestRunner test
```

## 4. When To Use Mobile Web

Use mobile web simulation when the product is a website or responsive web app. Use native mobile automation when the product is an installed `.apk`, `.aab`, `.app`, or `.ipa` app.
