# Mobile Native Automation With Appium

Native mobile automation is separate from web automation and uses the `@mobile_native` tag.

## 1. Configure Appium

Edit:

```text
src/test/resources/mobile/native/mobile-native-config.yml
```

For Android:

```yaml
mobileNative:
  platform: "android"
  serverUrl: "http://127.0.0.1:4723"
  android:
    deviceName: "Android Emulator"
    appPackage: "com.example.android"
    appActivity: ".MainActivity"
```

For iOS:

```yaml
mobileNative:
  platform: "ios"
  serverUrl: "http://127.0.0.1:4723"
  ios:
    deviceName: "iPhone 17 Pro Max"
    bundleId: "com.example.ios"
```

Use `app` when you want Appium to install an application file. Use `appPackage/appActivity` or `bundleId` when the app is already installed.

## 2. Add Native Locators

Edit:

```text
src/test/resources/mobile/native/native-sample-elements.yml
```

Example:

```yaml
mobileNativeElements:
  login:
    usernameInput: "ACCESSIBILITY_Username"
    submitButton: "ID_com.example:id/submit"
```

Supported locator prefixes:

```text
ACCESSIBILITY_
ID_
XPATH_
CLASS_
ANDROID_UIAUTOMATOR_
IOS_PREDICATE_
IOS_CLASS_CHAIN_
TEXT_
```

## 3. Write A Feature

Tag native scenarios with `@mobile_native`:

```gherkin
@mobile_native
Scenario: User can log in
  Then we tap on native page login locator usernameInput
  Then we enter value on native page login locator usernameInput value "new.joiner"
  Then we tap on native page login locator submitButton
```

## 4. Run Native Tests

Start Appium first, then run:

```bash
mvn -Dtest=MobileNativeTestRunner test
```

## 5. Action Coverage

Native step coverage includes tap, type, clear, waits, visibility, enabled, selected, text checks, attribute checks, count checks, swipe, long press, drag and drop, back, hide keyboard, screenshots, and alert accept or dismiss.
