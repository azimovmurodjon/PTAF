# PTAF One Week New Joiner Training Plan

This plan teaches the framework from the outside in: run first, understand second, extend third.

## Day 1: Framework Map

Goal: understand where things live.

1. Read `ReadMe.md`.
2. Open `src/test/resources/features` and inspect a few feature files.
3. Open `src/test/java/com/ptaf/stepdefinitions`.
4. Open `src/main/java/com/ptaf`.
5. Learn the pattern: feature step -> step definition -> common method -> action performer -> YAML locator/config.

Checkpoint: explain one web step from Gherkin down to the locator YAML.

## Day 2: Web UI Automation

Goal: write and run a small web test.

1. Add a locator YAML entry under `src/test/resources/elements`.
2. Write a scenario using existing steps.
3. Run the matching runner.
4. Review the generated report.
5. If a locator fails, review the page manually and improve the YAML locator.

Checkpoint: create one passing web scenario without adding Java code.

## Day 3: API And Database Concepts

Goal: understand non-UI layers.

1. Review `src/test/resources/api_requests`.
2. Review `src/main/java/com/ptaf/api`.
3. Review `src/test/resources/queries`.
4. Review `src/main/java/com/ptaf/db`.
5. Compare the shared pattern with web: YAML data, reusable Java methods, Cucumber steps.

Checkpoint: explain how the same framework style supports UI, API, and DB tests.

## Day 4: Mobile Web

Goal: run existing web tests as mobile browser simulations.

1. Open `docs/mobile-web/01-device-simulation.md`.
2. Change `browser` in `src/test/resources/config/config.yml` to `iPhone 17 Pro Max Safari`.
3. Run `MobileWebTestRunner`.
4. Repeat with one Android profile, such as `Pixel 10 Pro XL Chrome`.
5. Keep test steps unchanged and only change the browser profile.

Checkpoint: explain why mobile web uses Playwright and not Appium.

## Day 5: Native Mobile

Goal: understand Appium execution.

1. Start an Android emulator or iOS simulator.
2. Start Appium.
3. Configure `src/test/resources/mobile/native/mobile-native-config.yml`.
4. Add or update locators in `src/test/resources/mobile/native/native-sample-elements.yml`.
5. Run `MobileNativeTestRunner`.

Checkpoint: write one native scenario using `@mobile_native`.

## Day 6: Debugging And Reports

Goal: learn how to investigate failures.

1. Read the Cucumber output first.
2. Check the Extent report.
3. Check screenshots and captured videos when enabled.
4. For web failures, inspect the page and compare the real element with the YAML locator.
5. For native failures, confirm Appium server, device name, app id, and locator strategy.

Checkpoint: intentionally break one locator, observe the failure, then fix it.

## Day 7: Framework Extension Rules

Goal: extend safely.

1. Prefer YAML changes before Java changes.
2. Reuse existing common methods before adding new ones.
3. Add new steps only when the language is genuinely missing.
4. Keep mobile native under `@mobile_native`.
5. Keep mobile web as a browser profile.
6. Compile before raising a pull request.
7. Include one example feature for any new capability.

Checkpoint: add one small reusable action and document it.
