package com.ptaf.runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {
                "pretty",
                "html:target/mobile-native-cucumber-report.html",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
                "timeline:test-output-thread/mobile-native"
        },
        tags = "@mobile_native",
        features = "src/test/resources/features/mobile_native",
        glue = {"com/ptaf/stepdefinitions", "com/ptaf/mobile/nativeapp/hooks"}
)
public class MobileNativeTestRunner {
}
