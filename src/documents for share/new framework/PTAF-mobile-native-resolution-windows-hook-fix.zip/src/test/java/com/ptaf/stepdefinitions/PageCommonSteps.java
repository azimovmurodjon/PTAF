package com.ptaf.stepdefinitions;

import com.microsoft.playwright.Page;
import com.ptaf.hooks.Hooks;
import com.ptaf.ui.pages.PageCommonMethods;
import com.ptaf.utils.ConfigurationProperties;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PageCommonSteps {
    private Page page;
    private PageCommonMethods pageCommonMethods;
    private static final Logger logger = LoggerFactory.getLogger(PageCommonSteps.class);

    private Page getActivePage() {
        if (page == null || page.isClosed()) {
            page = Hooks.getPage();
        }
        return page;
    }

    private PageCommonMethods getPageCommonMethods() {
        if (pageCommonMethods == null) {
            pageCommonMethods = new PageCommonMethods(getActivePage());
        }
        return pageCommonMethods;
    }

//    public void switchToIframe() {
//        Page iframePage = page.waitForPopup(() -> {
//            page.frameLocator("iframe").getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Continue")).click();
//        });
//    }
//
//    @Given("^we navigate to (.*?) url$")
//    public void weNavigateToURL(String URL) {
//        page.navigate(ConfigurationProperties.getBaseUrl(URL));
////        page.setViewportSize(1920, 1080);
//        switchToIframe();
//    }

    @Then("^we click on page (.*?) locator (.*?)$")
    public void weClickActionOnPage(String element, String locator) {
        getPageCommonMethods().click(getActivePage(), element, locator);
    }

    @Then("^we double click on page (.*?) locator (.*?)$")
    public void weDoubleClickActionOnPage(String element, String locator) {
        getPageCommonMethods().dblclick(getActivePage(), element, locator);
    }

    @Then("^we enter value on page (.*?) locator (.*?) value \"(.*?)\"$")
    public void weEnterValueOnPage(String element, String locator, String value) {
        getPageCommonMethods().fill(getActivePage(), element, locator, value);
    }

    @Then("^we select on page (.*?) locator (.*?) value \"(.*?)\"$")
    public void weSelectValueOnPage(String element, String locator, String value) {
        getPageCommonMethods().select(getActivePage(), element, locator, value);
    }

    @Then("^we check on page (.*?) locator (.*?)$")
    public void weCheckActionOnPage(String element, String locator) {
        getPageCommonMethods().check(getActivePage(), element, locator);
    }

    @Then("^we uncheck on page (.*?) locator (.*?)$")
    public void weUncheckActionOnPage(String element, String locator) {
        getPageCommonMethods().check(getActivePage(), element, locator);
    }

    @Then("^we hover on page (.*?) locator (.*?)$")
    public void weHoverActionOnPage(String element, String locator) {
        getPageCommonMethods().hover(getActivePage(), element, locator);
    }

    @Then("^we type on page (.*?) locator (.*?) value \"(.*?)\"$")
    public void weTypeValueOnPage(String element, String locator, String value) {
        getPageCommonMethods().type(getActivePage(), element, locator, value);
    }

    @Then("^we scroll on page (.*?) locator (.*?)$")
    public void weScrollToLocatorOnPage(String element, String locator) {
        getPageCommonMethods().scroll(getActivePage(), element, locator);
    }

    @Then("^we clear value on page (.*?) locator (.*?) value \"(.*?)\"$")
    public void weClearValueOnPage(String element, String locator) {
        getPageCommonMethods().clear(getActivePage(), element, locator);
    }

    @Then("^we verify on page (.*?) of locator (.*?) is visible$")
    public void weVerifyOnPageLocatorIsVisible(String element, String locator) {
        getPageCommonMethods().isvisible(getActivePage(), element, locator);
    }

    @Then("^we verify on page (.*?) of locator (.*?) is checked$")
    public void weVerifyOnPageLocatorIsChecked(String element, String locator) {
        getPageCommonMethods().ischecked(getActivePage(), element, locator);
    }

    @Then("^we verify on page (.*?) of locator (.*?) is enabled")
    public void weVerifyOnPageLocatorIsEnabled(String element, String locator) {
        getPageCommonMethods().isenabled(getActivePage(), element, locator);
    }

    @Then("^we verify on page (.*?) of locator (.*?) is existed")
    public void weVerifyOnPageLocatorIsExisted(String element, String locator) {
        getPageCommonMethods().exists(getActivePage(), element, locator);
    }

    @Then("^we contain on page (.*?) of locator (.*?) value \"(.*?)\"$")
    public void weContainOnPageLocatorValue(String element, String locator, String value) {
        getPageCommonMethods().contain(getActivePage(), element, locator, value);
    }

    @Then("^we get text on page (.*?) locator (.*?)$")
    public void weGetTextOnPage(String element, String locator) {
        getPageCommonMethods().gettext(getActivePage(), element, locator);
    }

    @Then("^we get value on page (.*?) locator (.*?)$")
    public void weGetValueOnPage(String element, String locator) {
        getPageCommonMethods().getvalue(getActivePage(), element, locator);
    }

    @Then("^we has value on page (.*?) of locator (.*?) value \"(.*?)\"$")
    public void weHasValueOnPageLocatorValue(String element, String locator, String value) {
        getPageCommonMethods().hasvalue(getActivePage(), element, locator, value);
    }

    @Then("^we get list of elements on page (.*?) locator (.*?)$")
    public void weGetListOfElementsOnPage(String element, String locator) {
        getPageCommonMethods().getListOfElements(getActivePage(), element, locator);
    }

    @Then("^we get text of elements on page (.*?) locator (.*?)$")
    public void weGetTextOfElementsOnPage(String element, String locator) {
        String value = getPageCommonMethods().gettext(getActivePage(), element, locator);
        System.out.println("Value: " + value);
    }

    @When("we click radio on page (.*?) list locator (.*?)$")
    public void clickRadioOnPage(String element, String locator) {
        getPageCommonMethods().clickRadioButton(getActivePage(), element, locator);
    }

    @And("^we capture screenshot on page (.*?) locator (.*?) name \"(.*?)\"$")
    public void weCaptureScreenshotOnPage(String element, String locator, String name) {
        String filePath = "test-output/screenshots/" + name + ".png";
        getPageCommonMethods().screenshot(getActivePage(), element, locator, filePath);
    }

    @And("^we press on page (.*?) locator (.*?) key \"(.*?)\" keyboard$")
    public void wePressOnPageKey(String element, String locator, String value) {
        getPageCommonMethods().press(getActivePage(), element, locator, value);
    }

    @And("^we click download on page (.*?) locator (.*?)$")
    public void weDownloadOnPageKey(String element, String locator) {
        String filePath = ConfigurationProperties.getValue("downloadDocument");
        getPageCommonMethods().download(getActivePage(), element, locator, filePath + ".jpeg");
    }

    @And("^we select document to upload on page (.*?) locator (.*?)$")
    public void weSelectDocument(String element, String locator) {
        String filePath = ConfigurationProperties.getValue("downloadDocument");
        getPageCommonMethods().selectFile(getActivePage(), element, locator, "Mobile Automation Platforms.docx");
    }

    @Given("^get title of page$")
    public void getTitleOfPage() {
        String title = getActivePage().title();
        logger.info("Page title: {}", title);
    }

    @And("^we wait for some time$")
    public void weWaitForSomeTime() throws InterruptedException {
        Thread.sleep(3000);
    }

    @And("^time out for (.*?) seconds$")
    public void timeOutFoSeconds(String time_to_wait) throws InterruptedException {
        // Convert the string to an integer representing seconds
        int seconds = Integer.parseInt(time_to_wait);

        // Wait for the specified number of seconds (converted to milliseconds)
        Thread.sleep(seconds * 1000L);
    }

    @Then("^Stop Execution")
    public void stopExecution() throws Exception
    {
        Thread.sleep(30000);

    }

    @Then("^we close all browsers$")
    public void weCloseAllBrowsers() throws Exception{
        Hooks.closeBrowserResources();
    }
}
