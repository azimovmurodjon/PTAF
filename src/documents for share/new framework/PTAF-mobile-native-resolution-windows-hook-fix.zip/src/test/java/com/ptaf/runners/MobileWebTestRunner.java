package com.ptaf.runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {
                "pretty",
                "html:target/mobile-web-cucumber-report.html",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
                "timeline:test-output-thread/mobile-web"
        },
        tags = "@mobile_web",
        features = "src/test/resources/features/mobile_web",
        glue = {"com/ptaf/stepdefinitions", "com/ptaf/hooks"}
)
public class MobileWebTestRunner {
}
