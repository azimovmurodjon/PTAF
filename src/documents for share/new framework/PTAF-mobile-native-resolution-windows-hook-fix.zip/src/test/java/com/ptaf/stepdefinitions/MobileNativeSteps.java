package com.ptaf.stepdefinitions;

import com.ptaf.mobile.nativeapp.config.MobileNativeConfigurationProperties;
import com.ptaf.mobile.nativeapp.driver.MobileNativeDriverManager;
import com.ptaf.mobile.nativeapp.pages.MobileNativeCommonMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import java.time.Duration;

public class MobileNativeSteps {

    @Then("^we tap on native page (.*?) locator (.*?)$")
    public void weTapOnNativePageLocator(String page, String locator) {
        nativeMethods().tap(page, locator);
    }

    @Then("^we enter value on native page (.*?) locator (.*?) value \"(.*?)\"$")
    public void weEnterValueOnNativePageLocator(String page, String locator, String value) {
        nativeMethods().type(page, locator, value);
    }

    @Then("^we clear value on native page (.*?) locator (.*?)$")
    public void weClearValueOnNativePageLocator(String page, String locator) {
        nativeMethods().clear(page, locator);
    }

    @Then("^we wait until native page (.*?) locator (.*?) is visible$")
    public void weWaitUntilNativePageLocatorIsVisible(String page, String locator) {
        nativeMethods().waitVisible(page, locator);
    }

    @Then("^we wait until native page (.*?) locator (.*?) is clickable$")
    public void weWaitUntilNativePageLocatorIsClickable(String page, String locator) {
        nativeMethods().waitClickable(page, locator);
    }

    @Then("^we verify native page (.*?) locator (.*?) is visible$")
    public void weVerifyNativePageLocatorIsVisible(String page, String locator) {
        nativeMethods().verifyVisible(page, locator);
    }

    @Then("^we verify native page (.*?) locator (.*?) is enabled$")
    public void weVerifyNativePageLocatorIsEnabled(String page, String locator) {
        nativeMethods().verifyEnabled(page, locator);
    }

    @Then("^we verify native page (.*?) locator (.*?) is selected$")
    public void weVerifyNativePageLocatorIsSelected(String page, String locator) {
        nativeMethods().verifySelected(page, locator);
    }

    @Then("^we verify native page (.*?) locator (.*?) text equals \"(.*?)\"$")
    public void weVerifyNativePageLocatorTextEquals(String page, String locator, String value) {
        nativeMethods().verifyTextEquals(page, locator, value);
    }

    @Then("^we verify native page (.*?) locator (.*?) text contains \"(.*?)\"$")
    public void weVerifyNativePageLocatorTextContains(String page, String locator, String value) {
        nativeMethods().verifyTextContains(page, locator, value);
    }

    @Then("^we verify native page (.*?) locator (.*?) attribute (.*?) equals \"(.*?)\"$")
    public void weVerifyNativePageLocatorAttributeEquals(String page, String locator, String attribute, String value) {
        nativeMethods().verifyAttributeEquals(page, locator, attribute, value);
    }

    @Then("^we verify native page (.*?) locator (.*?) attribute (.*?) contains \"(.*?)\"$")
    public void weVerifyNativePageLocatorAttributeContains(String page, String locator, String attribute, String value) {
        nativeMethods().verifyAttributeContains(page, locator, attribute, value);
    }

    @Then("^we verify native page (.*?) locator (.*?) count is (\\d+)$")
    public void weVerifyNativePageLocatorCountIs(String page, String locator, int expectedCount) {
        nativeMethods().verifyCount(page, locator, expectedCount);
    }

    @And("^we swipe native screen (up|down|left|right)$")
    public void weSwipeNativeScreen(String direction) {
        nativeMethods().swipe(direction);
    }

    @And("^we long press native page (.*?) locator (.*?)$")
    public void weLongPressNativePageLocator(String page, String locator) {
        nativeMethods().longPress(page, locator);
    }

    @And("^we drag native page (.*?) locator (.*?) to native page (.*?) locator (.*?)$")
    public void weDragNativePageLocatorToNativePageLocator(
            String sourcePage,
            String sourceLocator,
            String targetPage,
            String targetLocator
    ) {
        nativeMethods().dragDrop(sourcePage, sourceLocator, targetPage, targetLocator);
    }

    @And("^we go back on native app$")
    public void weGoBackOnNativeApp() {
        nativeMethods().back();
    }

    @And("^we hide native keyboard$")
    public void weHideNativeKeyboard() {
        nativeMethods().hideKeyboard();
    }

    @And("^we capture native screenshot named \"(.*?)\"$")
    public void weCaptureNativeScreenshotNamed(String name) {
        nativeMethods().screenshot(name);
    }

    @And("^we accept native alert$")
    public void weAcceptNativeAlert() {
        nativeMethods().acceptAlert();
    }

    @And("^we dismiss native alert$")
    public void weDismissNativeAlert() {
        nativeMethods().dismissAlert();
    }

    private MobileNativeCommonMethods nativeMethods() {
        return new MobileNativeCommonMethods(
                MobileNativeDriverManager.getDriver(),
                Duration.ofSeconds(MobileNativeConfigurationProperties.getImplicitWaitSeconds())
        );
    }
}
