package com.ptaf.stepdefinitions;

import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import com.ptaf.hooks.Hooks;
import com.ptaf.ui.pages.FrameCommonMethods;
import com.ptaf.utils.ConfigurationProperties;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FrameCommonSteps {
    private Page page;
    private static Page iframePage;
    private final String iFrame = "#frame1";
    private final String iFrame_2 = "iframe";
    private final String iFrame_3 = null;
    private FrameCommonMethods frameCommonMethods;

    public FrameCommonSteps() {
    }

    private Page getActivePage() {
        if (page == null || page.isClosed()) {
            page = Hooks.getPage();
        }
        return page;
    }

    private FrameCommonMethods getFrameCommonMethods() {
        if (frameCommonMethods == null) {
            frameCommonMethods = new FrameCommonMethods(getActivePage());
        }
        return frameCommonMethods;
    }

    public void switchToIframe() {
        iframePage = getActivePage().waitForPopup(() -> {
            getActivePage().frameLocator("iframe").getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Continue")).click();
        });
    }

    @Given("^we navigate to (.*?) url$")
    public void weNavigateToURL(String URL) {
        getActivePage().navigate(ConfigurationProperties.getBaseUrl(URL));
//        page.setViewportSize(1920, 1080);
//        switchToIframe();
    }

    @Then("^we click on frame (.*?) locator (.*?)$")
    public void weClickActionOnPage(String element, String locator) {
        getFrameCommonMethods().click(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we double click on frame (.*?) locator (.*?)$")
    public void weDoubleClickActionOnPage(String element, String locator) {
        getFrameCommonMethods().dblclick(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we enter value on frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weEnterValueOnPage(String element, String locator, String value) {
        getFrameCommonMethods().fill(getActivePage(), iFrame, null, null,element, locator, value);
    }

    @Then("^we select on frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weSelectValueOnPage(String element, String locator, String value) {
        getFrameCommonMethods().select(getActivePage(), iFrame, null, null, element, locator, value);
    }

    @Then("^we check on frame (.*?) locator (.*?)$")
    public void weCheckActionOnPage(String element, String locator) {
        getFrameCommonMethods().check(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we uncheck on frame (.*?) locator (.*?)$")
    public void weUncheckActionOnPage(String element, String locator) {
        getFrameCommonMethods().check(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we hover on frame (.*?) locator (.*?)$")
    public void weHoverActionOnPage(String element, String locator) {
        getFrameCommonMethods().hover(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we type on frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weTypeValueOnPage(String element, String locator, String value) {
        getFrameCommonMethods().type(getActivePage(), iFrame, null, null, element, locator, value);
    }

    @Then("^we scroll on frame (.*?) locator (.*?)$")
    public void weScrollToLocatorOnPage(String element, String locator) {
        getFrameCommonMethods().scroll(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we clear value on frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weClearValueOnPage(String element, String locator) {
        getFrameCommonMethods().clear(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we verify on frame (.*?) of locator (.*?) is visible$")
    public void weVerifyOnPageLocatorIsVisible(String element, String locator) {
        getFrameCommonMethods().isvisible(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we verify on frame (.*?) of locator (.*?) is checked$")
    public void weVerifyOnPageLocatorIsChecked(String element, String locator) {
        getFrameCommonMethods().ischecked(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we verify on frame (.*?) of locator (.*?) is enabled")
    public void weVerifyOnPageLocatorIsEnabled(String element, String locator) {
        getFrameCommonMethods().isenabled(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we verify on frame (.*?) of locator (.*?) is existed")
    public void weVerifyOnPageLocatorIsExisted(String element, String locator) {
        getFrameCommonMethods().exists(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we contain on frame (.*?) of locator (.*?) value \"(.*?)\"$")
    public void weContainOnPageLocatorValue(String element, String locator, String value) {
        getFrameCommonMethods().contain(getActivePage(), iFrame, null, null, element, locator, value);
    }

    @Then("^we get text on frame (.*?) locator (.*?)$")
    public void weGetTextOnPage(String element, String locator) {
        String value = getFrameCommonMethods().gettext(getActivePage(), iFrame, null, null, element, locator);
        System.out.println("Value: " + value);
    }

    @Then("^we has value on frame (.*?) of locator (.*?) value \"(.*?)\"$")
    public void weHasValueOnNewPageLocatorValue(String element, String locator, String value) {
        getFrameCommonMethods().hasvalue(getActivePage(), iFrame, null, null, element, locator, value);
    }

    @Then("^we get list of elements on frame (.*?) locator (.*?)$")
    public void weGetListOfElementsOnNewPage(String element, String locator) {
        getFrameCommonMethods().gettext(getActivePage(), iFrame, null, null, element, locator);
    }

    @When("we click radio on frame (.*?) list locator (.*?)$")
    public void clickRadioOnNewPage(String element, String locator) {
        getFrameCommonMethods().clickRadioButton(getActivePage(), iFrame, element, locator);
    }

    @And("^we capture screenshot on frame (.*?) locator (.*?) name \"(.*?)\"$")
    public void weCaptureScreenshotOnPage(String element, String locator, String name) {
        String filePath = "test-output/screenshots/" + name + ".png";
        getFrameCommonMethods().screenshot(getActivePage(), iFrame, null, null, element, locator, filePath);
    }

    @And("^we press on frame (.*?) locator (.*?) key \"(.*?)\" keyboard$")
    public void wePressOnPageKey(String element, String locator, String value) {
        getFrameCommonMethods().press(getActivePage(), iFrame, null, null, element, locator, value);
    }

    @Then("^we click on second frame (.*?) locator (.*?)$")
    public void weClickActionOnSecondFrame(String element, String locator) {
        getFrameCommonMethods().click(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we double click on second frame (.*?) locator (.*?)$")
    public void weDoubleClickActionOnSecondFrame(String element, String locator) {
        getFrameCommonMethods().dblclick(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we enter value on second frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weEnterValueOnSecondFrame(String element, String locator, String value) {
        getFrameCommonMethods().fill(getActivePage(), iFrame, iFrame_2, null,element, locator, value);
    }

    @Then("^we select on second frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weSelectValueOnSecondFrame(String element, String locator, String value) {
        getFrameCommonMethods().select(getActivePage(), iFrame, iFrame_2, null, element, locator, value);
    }

    @Then("^we check on second frame (.*?) locator (.*?)$")
    public void weCheckActionOnSecondFrame(String element, String locator) {
        getFrameCommonMethods().check(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we uncheck on second frame (.*?) locator (.*?)$")
    public void weUncheckActionOnSecondFrame(String element, String locator) {
        getFrameCommonMethods().check(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we hover on second frame (.*?) locator (.*?)$")
    public void weHoverActionOnSecondFrame(String element, String locator) {
        getFrameCommonMethods().hover(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we type on second frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weTypeValueOnSecondFrame(String element, String locator, String value) {
        getFrameCommonMethods().type(getActivePage(), iFrame, iFrame_2, null, element, locator, value);
    }

    @Then("^we scroll on second frame (.*?) locator (.*?)$")
    public void weScrollToLocatorOnSecondFrame(String element, String locator) {
        getFrameCommonMethods().scroll(getActivePage(), iFrame, null, null, element, locator);
    }

    @Then("^we clear value on second frame (.*?) locator (.*?) value \"(.*?)\"$")
    public void weClearValueOnSecondFrame(String element, String locator) {
        getFrameCommonMethods().clear(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we verify on second frame (.*?) of locator (.*?) is visible$")
    public void weVerifyOnSecondFrameLocatorIsVisible(String element, String locator) {
        getFrameCommonMethods().isvisible(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we verify on second frame (.*?) of locator (.*?) is checked$")
    public void weVerifyOnSecondFrameLocatorIsChecked(String element, String locator) {
        getFrameCommonMethods().ischecked(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we verify on second frame (.*?) of locator (.*?) is enabled")
    public void weVerifyOnSecondFrameLocatorIsEnabled(String element, String locator) {
        getFrameCommonMethods().isenabled(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we verify on second frame (.*?) of locator (.*?) is existed")
    public void weVerifyOnSecondFrameLocatorIsExisted(String element, String locator) {
        getFrameCommonMethods().exists(getActivePage(), iFrame, iFrame_2, null, element, locator);
    }

    @Then("^we contain on second frame (.*?) of locator (.*?) value \"(.*?)\"$")
    public void weContainOnSecondFrameLocatorValue(String element, String locator, String value) {
        getFrameCommonMethods().contain(getActivePage(), iFrame, iFrame_2, null, element, locator, value);
    }

    @Then("^we get text on second frame (.*?) locator (.*?)$")
    public void weGetTextOnSecondFrame(String element, String locator) {
        String value = getFrameCommonMethods().gettext(getActivePage(), iFrame, iFrame_2, null, element, locator);
        System.out.println("Value: " + value);
    }

    @And("^we capture screenshot on second frame (.*?) locator (.*?) name \"(.*?)\"$")
    public void weCaptureScreenshotOnSecondFrame(String element, String locator, String name) {
        String filePath = "test-output/screenshots/" + name + ".png";
        getFrameCommonMethods().screenshot(getActivePage(), iFrame, iFrame_2, null, element, locator, filePath);
    }

    @And("^we press on second frame (.*?) locator (.*?) key \"(.*?)\" keyboard$")
    public void wePressOnSecondFrameKey(String element, String locator, String value) {
        getFrameCommonMethods().press(getActivePage(), iFrame, iFrame_2, null, element, locator, value);
    }
}
