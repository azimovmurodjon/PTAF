@mobile_web
Feature: Mobile web browser simulation

  Scenario: Run the existing web steps through a configured mobile device profile
    Given we navigate to tool_qa_url url
    Then get title of page
