@mobile_native @android_native
Feature: Android native app smoke validation

  Scenario: Login screen accepts user input
    Then we wait until native page sample locator loginButton is visible
    Then we tap on native page sample locator loginButton
    Then we enter value on native page sample locator usernameInput value "new.joiner"
    Then we enter value on native page sample locator passwordInput value "training-password"
    And we hide native keyboard
    Then we tap on native page sample locator submitButton
    Then we verify native page sample locator welcomeMessage is visible
    And we capture native screenshot named "android-login-smoke"

  Scenario: Common gestures are available for native screens
    And we swipe native screen up
    Then we wait until native page sample locator listItem is visible
    And we long press native page sample locator listItem
    And we go back on native app
