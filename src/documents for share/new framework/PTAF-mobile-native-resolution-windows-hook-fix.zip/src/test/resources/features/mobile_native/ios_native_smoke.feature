@mobile_native @ios_native
Feature: iOS native app smoke validation

  Scenario: Settings screen can be validated on iOS
    Then we wait until native page sample locator settingsTab is visible
    Then we tap on native page sample locator settingsTab
    Then we verify native page sample locator iosSettingsCell is visible
    Then we verify native page sample locator switchControl is enabled
    And we capture native screenshot named "ios-settings-smoke"
