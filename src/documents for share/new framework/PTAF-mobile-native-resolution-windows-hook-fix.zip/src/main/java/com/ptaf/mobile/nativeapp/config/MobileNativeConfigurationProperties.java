package com.ptaf.mobile.nativeapp.config;

import com.ptaf.utils.ConfigurationProperties;

public class MobileNativeConfigurationProperties {

    private static final String ROOT = "mobileNative.";

    private MobileNativeConfigurationProperties() {
    }

    public static String getPlatform() {
        return getValue("platform", "android").trim().toLowerCase();
    }

    public static String getServerUrl() {
        return getValue("serverUrl", "http://127.0.0.1:4723");
    }

    public static int getImplicitWaitSeconds() {
        String value = getValue("implicitWaitSeconds", "5");
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return 5;
        }
    }

    public static String getAndroidValue(String key) {
        return getValue("android." + key, "");
    }

    public static String getIosValue(String key) {
        return getValue("ios." + key, "");
    }

    public static boolean getAndroidBoolean(String key, boolean defaultValue) {
        return Boolean.parseBoolean(getValue("android." + key, String.valueOf(defaultValue)));
    }

    public static boolean getIosBoolean(String key, boolean defaultValue) {
        return Boolean.parseBoolean(getValue("ios." + key, String.valueOf(defaultValue)));
    }

    private static String getValue(String key, String defaultValue) {
        String value = ConfigurationProperties.getValue(ROOT + key);
        return value == null || value.isBlank() ? defaultValue : value;
    }
}
