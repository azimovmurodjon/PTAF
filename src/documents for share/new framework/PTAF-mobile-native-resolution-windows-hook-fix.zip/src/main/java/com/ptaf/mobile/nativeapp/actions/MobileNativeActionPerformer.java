package com.ptaf.mobile.nativeapp.actions;

import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;

public class MobileNativeActionPerformer {

    private final AppiumDriver driver;
    private final WebDriverWait wait;

    public MobileNativeActionPerformer(AppiumDriver driver, Duration timeout) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, timeout);
    }

    public void tap(By locator) {
        wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
    }

    public void type(By locator, String value) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        element.clear();
        element.sendKeys(value);
    }

    public void clear(By locator) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).clear();
    }

    public boolean isVisible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
    }

    public boolean isEnabled(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator)).isEnabled();
    }

    public boolean isSelected(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator)).isSelected();
    }

    public String text(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).getText();
    }

    public String attribute(By locator, String attributeName) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator)).getAttribute(attributeName);
    }

    public int count(By locator) {
        return driver.findElements(locator).size();
    }

    public void waitVisible(By locator) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public void waitClickable(By locator) {
        wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public void swipe(String direction) {
        Dimension size = driver.manage().window().getSize();
        int centerX = size.getWidth() / 2;
        int centerY = size.getHeight() / 2;
        int topY = (int) (size.getHeight() * 0.20);
        int bottomY = (int) (size.getHeight() * 0.80);
        int leftX = (int) (size.getWidth() * 0.20);
        int rightX = (int) (size.getWidth() * 0.80);

        switch (direction.trim().toLowerCase()) {
            case "up" -> drag(centerX, bottomY, centerX, topY, 600);
            case "down" -> drag(centerX, topY, centerX, bottomY, 600);
            case "left" -> drag(rightX, centerY, leftX, centerY, 600);
            case "right" -> drag(leftX, centerY, rightX, centerY, 600);
            default -> throw new IllegalArgumentException("Unsupported swipe direction: " + direction);
        }
    }

    public void longPress(By locator) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        int centerX = element.getRect().getX() + element.getRect().getWidth() / 2;
        int centerY = element.getRect().getY() + element.getRect().getHeight() / 2;
        drag(centerX, centerY, centerX, centerY, 1200);
    }

    public void dragDrop(By source, By target) {
        WebElement sourceElement = wait.until(ExpectedConditions.visibilityOfElementLocated(source));
        WebElement targetElement = wait.until(ExpectedConditions.visibilityOfElementLocated(target));

        int startX = sourceElement.getRect().getX() + sourceElement.getRect().getWidth() / 2;
        int startY = sourceElement.getRect().getY() + sourceElement.getRect().getHeight() / 2;
        int endX = targetElement.getRect().getX() + targetElement.getRect().getWidth() / 2;
        int endY = targetElement.getRect().getY() + targetElement.getRect().getHeight() / 2;

        drag(startX, startY, endX, endY, 800);
    }

    public void back() {
        driver.navigate().back();
    }

    public void hideKeyboard() {
        try {
            driver.executeScript("mobile: hideKeyboard");
        } catch (WebDriverException ignored) {
        }
    }

    public Path screenshot(String name) {
        try {
            Files.createDirectories(Path.of("test-output/mobile-native-screenshots"));
            File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Path target = Path.of("test-output/mobile-native-screenshots", name + ".png");
            Files.copy(source.toPath(), target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            return target;
        } catch (Exception e) {
            throw new RuntimeException("Unable to capture native mobile screenshot: " + name, e);
        }
    }

    public void acceptAlert() {
        driver.switchTo().alert().accept();
    }

    public void dismissAlert() {
        driver.switchTo().alert().dismiss();
    }

    private void drag(int startX, int startY, int endX, int endY, long durationMillis) {
        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence sequence = new Sequence(finger, 1);
        sequence.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, startY));
        sequence.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        sequence.addAction(new Pause(finger, Duration.ofMillis(200)));
        sequence.addAction(finger.createPointerMove(Duration.ofMillis(durationMillis), PointerInput.Origin.viewport(), endX, endY));
        sequence.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
        driver.perform(List.of(sequence));
    }
}
