package com.ptaf.mobile.nativeapp.driver;

import com.ptaf.mobile.nativeapp.config.MobileNativeConfigurationProperties;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class MobileNativeDriverManager {

    private static final Logger logger = LoggerFactory.getLogger(MobileNativeDriverManager.class);
    private static final ThreadLocal<AppiumDriver> driverThreadLocal = new ThreadLocal<>();

    private MobileNativeDriverManager() {
    }

    public static AppiumDriver createDriver() {
        String platform = MobileNativeConfigurationProperties.getPlatform();
        AppiumDriver driver = switch (platform) {
            case "android" -> createAndroidDriver();
            case "ios" -> createIosDriver();
            default -> throw new IllegalArgumentException("Unsupported native mobile platform: " + platform);
        };

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(
                MobileNativeConfigurationProperties.getImplicitWaitSeconds()
        ));
        driverThreadLocal.set(driver);
        logger.info("Native mobile driver created for platform: {}", platform);
        return driver;
    }

    public static AppiumDriver getDriver() {
        AppiumDriver driver = driverThreadLocal.get();
        if (driver == null) {
            throw new IllegalStateException("Native mobile driver is not initialized. Use @mobile_native scenario setup first.");
        }
        return driver;
    }

    public static void quitDriver() {
        try {
            AppiumDriver driver = driverThreadLocal.get();
            if (driver != null) {
                driver.quit();
                logger.info("Native mobile driver closed.");
            }
        } catch (Exception e) {
            logger.error("Error closing native mobile driver: {}", e.getMessage(), e);
        } finally {
            driverThreadLocal.remove();
        }
    }

    private static AndroidDriver createAndroidDriver() {
        UiAutomator2Options options = new UiAutomator2Options()
                .setDeviceName(MobileNativeConfigurationProperties.getAndroidValue("deviceName"))
                .setAutomationName("UiAutomator2")
                .setNoReset(MobileNativeConfigurationProperties.getAndroidBoolean("noReset", true))
                .setFullReset(MobileNativeConfigurationProperties.getAndroidBoolean("fullReset", false));

        setOptionalCapability(options, "platformVersion", MobileNativeConfigurationProperties.getAndroidValue("platformVersion"));
        setOptionalCapability(options, "app", MobileNativeConfigurationProperties.getAndroidValue("app"));
        setOptionalCapability(options, "appPackage", MobileNativeConfigurationProperties.getAndroidValue("appPackage"));
        setOptionalCapability(options, "appActivity", MobileNativeConfigurationProperties.getAndroidValue("appActivity"));

        return new AndroidDriver(serverUrl(), options);
    }

    private static IOSDriver createIosDriver() {
        XCUITestOptions options = new XCUITestOptions()
                .setDeviceName(MobileNativeConfigurationProperties.getIosValue("deviceName"))
                .setAutomationName("XCUITest")
                .setNoReset(MobileNativeConfigurationProperties.getIosBoolean("noReset", true))
                .setFullReset(MobileNativeConfigurationProperties.getIosBoolean("fullReset", false));

        setOptionalCapability(options, "platformVersion", MobileNativeConfigurationProperties.getIosValue("platformVersion"));
        setOptionalCapability(options, "app", MobileNativeConfigurationProperties.getIosValue("app"));
        setOptionalCapability(options, "bundleId", MobileNativeConfigurationProperties.getIosValue("bundleId"));

        return new IOSDriver(serverUrl(), options);
    }

    private static void setOptionalCapability(UiAutomator2Options options, String key, String value) {
        if (value != null && !value.isBlank()) {
            options.setCapability(key, value.trim());
        }
    }

    private static void setOptionalCapability(XCUITestOptions options, String key, String value) {
        if (value != null && !value.isBlank()) {
            options.setCapability(key, value.trim());
        }
    }

    private static URL serverUrl() {
        try {
            return new URL(MobileNativeConfigurationProperties.getServerUrl());
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("Invalid Appium server URL in mobileNative.serverUrl", e);
        }
    }
}
