package com.ptaf.mobile.nativeapp.hooks;

import com.ptaf.mobile.nativeapp.driver.MobileNativeDriverManager;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MobileNativeHooks {

    private static final Logger logger = LoggerFactory.getLogger(MobileNativeHooks.class);

    @Before("@mobile_native")
    public void setUpNativeMobile(Scenario scenario) {
        logger.info("Starting native mobile setup for scenario: {}", scenario.getName());
        MobileNativeDriverManager.createDriver();
    }

    @After("@mobile_native")
    public void tearDownNativeMobile(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                AppiumDriver driver = MobileNativeDriverManager.getDriver();
                byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                scenario.attach(screenshot, "image/png", scenario.getName());
            }
        } catch (Exception e) {
            logger.warn("Unable to attach native mobile failure screenshot: {}", e.getMessage());
        } finally {
            MobileNativeDriverManager.quitDriver();
        }
    }
}
