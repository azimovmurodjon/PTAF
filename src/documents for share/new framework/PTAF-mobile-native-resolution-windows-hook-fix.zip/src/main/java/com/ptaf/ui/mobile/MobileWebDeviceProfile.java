package com.ptaf.ui.mobile;

public class MobileWebDeviceProfile {
    private final String name;
    private final String browserEngine;
    private final String userAgent;
    private final int viewportWidth;
    private final int viewportHeight;
    private final int screenWidth;
    private final int screenHeight;
    private final double deviceScaleFactor;
    private final boolean mobile;
    private final boolean hasTouch;

    public MobileWebDeviceProfile(String name,
                                  String browserEngine,
                                  String userAgent,
                                  int viewportWidth,
                                  int viewportHeight,
                                  int screenWidth,
                                  int screenHeight,
                                  double deviceScaleFactor,
                                  boolean mobile,
                                  boolean hasTouch) {
        this.name = name;
        this.browserEngine = browserEngine;
        this.userAgent = userAgent;
        this.viewportWidth = viewportWidth;
        this.viewportHeight = viewportHeight;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.deviceScaleFactor = deviceScaleFactor;
        this.mobile = mobile;
        this.hasTouch = hasTouch;
    }

    public String getName() {
        return name;
    }

    public String getBrowserEngine() {
        return browserEngine;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public int getViewportWidth() {
        return viewportWidth;
    }

    public int getViewportHeight() {
        return viewportHeight;
    }

    public int getScreenWidth() {
        return screenWidth;
    }

    public int getScreenHeight() {
        return screenHeight;
    }

    public double getDeviceScaleFactor() {
        return deviceScaleFactor;
    }

    public boolean isMobile() {
        return mobile;
    }

    public boolean hasTouch() {
        return hasTouch;
    }
}
