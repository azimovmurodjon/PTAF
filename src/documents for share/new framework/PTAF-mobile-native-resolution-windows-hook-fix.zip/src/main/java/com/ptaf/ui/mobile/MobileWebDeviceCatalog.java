package com.ptaf.ui.mobile;

import com.ptaf.utils.YamlReader;

import java.util.Map;
import java.util.Optional;

public final class MobileWebDeviceCatalog {
    private static final String ROOT = "mobileWebDevices.";

    private MobileWebDeviceCatalog() {
    }

    @SuppressWarnings("unchecked")
    public static Optional<MobileWebDeviceProfile> findByName(String configuredBrowserName) {
        if (configuredBrowserName == null || configuredBrowserName.isBlank()) {
            return Optional.empty();
        }

        Object rawProfile = YamlReader.get(ROOT + configuredBrowserName.trim());
        if (!(rawProfile instanceof Map<?, ?> profileMap)) {
            return Optional.empty();
        }

        Map<String, Object> values = (Map<String, Object>) profileMap;
        return Optional.of(new MobileWebDeviceProfile(
                configuredBrowserName.trim(),
                getString(values, "browserEngine", "CHROMIUM"),
                getString(values, "userAgent", null),
                getInt(values, "viewportWidth"),
                getInt(values, "viewportHeight"),
                getInt(values, "screenWidth"),
                getInt(values, "screenHeight"),
                getDouble(values, "deviceScaleFactor", 1.0),
                getBoolean(values, "mobile", true),
                getBoolean(values, "hasTouch", true)
        ));
    }

    private static String getString(Map<String, Object> values, String key, String defaultValue) {
        Object value = values.get(key);
        return value == null ? defaultValue : String.valueOf(value);
    }

    private static int getInt(Map<String, Object> values, String key) {
        Object value = values.get(key);
        if (value == null) {
            throw new IllegalArgumentException("Mobile web device profile is missing required key: " + key);
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private static double getDouble(Map<String, Object> values, String key, double defaultValue) {
        Object value = values.get(key);
        return value == null ? defaultValue : Double.parseDouble(String.valueOf(value));
    }

    private static boolean getBoolean(Map<String, Object> values, String key, boolean defaultValue) {
        Object value = values.get(key);
        return value == null ? defaultValue : Boolean.parseBoolean(String.valueOf(value));
    }
}
