package com.ptaf.utils;

import com.microsoft.playwright.*;
import com.ptaf.ui.mobile.MobileWebDeviceCatalog;
import com.ptaf.ui.mobile.MobileWebDeviceProfile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Paths;
import java.util.Optional;

/**
 * BrowserFactory is a utility class for creating Playwright Browser instances.
 * It abstracts the browser creation logic, allowing users to easily instantiate
 * different types of browsers (Chrome, Firefox, WebKit, Microsoft Edge) based on their requirements.
 */
public class BrowserFactory {

    private static final Logger logger = LoggerFactory.getLogger(BrowserFactory.class);
    private static final String VIDEO_DIR = "test-output/captured-videos";
    private static final ThreadLocal<Playwright> playwrightThreadLocal = new ThreadLocal<>();
    private static final ThreadLocal<MobileWebDeviceProfile> mobileWebDeviceThreadLocal = new ThreadLocal<>();


    /**
     * Enum representing the supported browser types.
     */
    public enum BrowserTypeEnum {
        CHROME,
        FIREFOX,
        WEBKIT,
        EDGE
    }

    /**
     * Creates and launches a Playwright Browser instance based on the specified browser type.
     *
     * @param browserTypeEnum The type of browser to create.
     * @return A Playwright Browser instance.
     */
    public static Browser createBrowser(BrowserTypeEnum browserTypeEnum) {
        Playwright playwright = Playwright.create();
        playwrightThreadLocal.set(playwright);
        return switch (browserTypeEnum) {
            case CHROME -> {
                BrowserType browserType = playwright.chromium();
                yield launchBrowser(browserType);
            }
            case FIREFOX -> {
                BrowserType browserType = playwright.firefox();
                yield launchBrowser(browserType);
            }
            case WEBKIT -> {
                BrowserType browserType = playwright.webkit();
                yield launchBrowser(browserType);
            }
            case EDGE -> {
                boolean headless = Boolean.parseBoolean(ConfigurationProperties.getHeadlessMode());
                logger.info("Launching Microsoft Edge with headless mode: {}", headless);
                yield playwright.chromium().launch(new BrowserType.LaunchOptions()
                        .setChannel("msedge")
                        .setHeadless(headless));
            }
        };
    }

    /**
     * Launches the specified browser type with the configured headless mode.
     *
     * @param browserType The BrowserType instance.
     * @return The launched Browser.
     */
    private static Browser launchBrowser(BrowserType browserType) {
        boolean headless = Boolean.parseBoolean(ConfigurationProperties.getHeadlessMode());
        logger.info("Launching browser: {} with headless mode: {}", browserType.name().toUpperCase(), headless);
        return browserType.launch(new BrowserType.LaunchOptions().setHeadless(headless));
    }

    public static Browser createBrowser(String configuredBrowserName) {
        Optional<MobileWebDeviceProfile> mobileProfile = MobileWebDeviceCatalog.findByName(configuredBrowserName);
        if (mobileProfile.isPresent()) {
            return createMobileWebBrowser(mobileProfile.get());
        }

        return createBrowser(resolveBrowserType(configuredBrowserName));
    }

    private static Browser createMobileWebBrowser(MobileWebDeviceProfile profile) {
        Playwright playwright = Playwright.create();
        playwrightThreadLocal.set(playwright);
        mobileWebDeviceThreadLocal.set(profile);

        BrowserType browserType = switch (profile.getBrowserEngine().trim().toUpperCase()) {
            case "WEBKIT", "SAFARI" -> playwright.webkit();
            case "FIREFOX" -> playwright.firefox();
            case "CHROMIUM", "CHROME" -> playwright.chromium();
            default -> throw new IllegalArgumentException(
                    "Unsupported mobile web browser engine: " + profile.getBrowserEngine()
                            + " for device: " + profile.getName()
            );
        };

        boolean headless = Boolean.parseBoolean(ConfigurationProperties.getHeadlessMode());
        logger.info(
                "Launching mobile web profile '{}' using engine '{}' with headless mode: {}",
                profile.getName(),
                profile.getBrowserEngine(),
                headless
        );
        return browserType.launch(new BrowserType.LaunchOptions().setHeadless(headless));
    }

    private static BrowserTypeEnum resolveBrowserType(String browserName) {
        if (browserName == null || browserName.isBlank()) {
            throw new IllegalArgumentException("Browser type is not configured.");
        }

        return switch (browserName.trim().toUpperCase()) {
            case "CHROME", "CHROMIUM" -> BrowserTypeEnum.CHROME;
            case "FIREFOX" -> BrowserTypeEnum.FIREFOX;
            case "WEBKIT", "SAFARI" -> BrowserTypeEnum.WEBKIT;
            case "EDGE" -> BrowserTypeEnum.EDGE;
            default -> throw new IllegalArgumentException(
                    "Unsupported browser type or mobile device profile: " + browserName
            );
        };
    }

    /**
     * Creates a browser context with optional video capture.
     *
     * @param browser The Browser instance.
     * @return A BrowserContext with or without video enabled.
     */
    public static BrowserContext createContextWithVideo(Browser browser) {
        boolean recordVideo = Boolean.parseBoolean(ConfigurationProperties.getVideoCapture());
        Browser.NewContextOptions contextOptions = new Browser.NewContextOptions();
        MobileWebDeviceProfile mobileProfile = mobileWebDeviceThreadLocal.get();

        if (recordVideo) {
            logger.info("Video capture enabled.");
            contextOptions.setRecordVideoDir(Paths.get(VIDEO_DIR))
                    .setRecordVideoSize(1280, 720);
        } else {
            logger.info("Video capture disabled.");
        }

        if (mobileProfile != null) {
            contextOptions
                    .setViewportSize(mobileProfile.getViewportWidth(), mobileProfile.getViewportHeight())
                    .setScreenSize(mobileProfile.getScreenWidth(), mobileProfile.getScreenHeight())
                    .setDeviceScaleFactor(mobileProfile.getDeviceScaleFactor())
                    .setIsMobile(mobileProfile.isMobile())
                    .setHasTouch(mobileProfile.hasTouch());

            if (mobileProfile.getUserAgent() != null && !mobileProfile.getUserAgent().isBlank()) {
                contextOptions.setUserAgent(mobileProfile.getUserAgent());
            }

            logger.info(
                    "Applied mobile web emulation profile '{}': viewport={}x{}, screen={}x{}, dpr={}",
                    mobileProfile.getName(),
                    mobileProfile.getViewportWidth(),
                    mobileProfile.getViewportHeight(),
                    mobileProfile.getScreenWidth(),
                    mobileProfile.getScreenHeight(),
                    mobileProfile.getDeviceScaleFactor()
            );
        }

        return browser.newContext(contextOptions);
    }

    public static void closePlaywright() {
        try {
            Playwright playwright = playwrightThreadLocal.get();
            if (playwright != null) {
                playwright.close();
                logger.info("Playwright instance closed.");
            }
        } catch (Exception e) {
            logger.error("Error closing Playwright instance: {}", e.getMessage(), e);
        } finally {
            playwrightThreadLocal.remove();
            mobileWebDeviceThreadLocal.remove();
        }
    }
}
