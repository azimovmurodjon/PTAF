package com.ptaf.mobile.nativeapp.pages;

import com.ptaf.mobile.nativeapp.actions.MobileNativeActionPerformer;
import com.ptaf.mobile.nativeapp.handlers.MobileNativeLocatorHandler;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;

import java.time.Duration;

public class MobileNativeCommonMethods {

    private final MobileNativeLocatorHandler locatorHandler = new MobileNativeLocatorHandler();
    private final MobileNativeActionPerformer actionPerformer;

    public MobileNativeCommonMethods(AppiumDriver driver, Duration timeout) {
        this.actionPerformer = new MobileNativeActionPerformer(driver, timeout);
    }

    public void tap(String page, String locator) {
        actionPerformer.tap(resolve(page, locator));
    }

    public void type(String page, String locator, String value) {
        actionPerformer.type(resolve(page, locator), value);
    }

    public void clear(String page, String locator) {
        actionPerformer.clear(resolve(page, locator));
    }

    public void waitVisible(String page, String locator) {
        actionPerformer.waitVisible(resolve(page, locator));
    }

    public void waitClickable(String page, String locator) {
        actionPerformer.waitClickable(resolve(page, locator));
    }

    public void verifyVisible(String page, String locator) {
        if (!actionPerformer.isVisible(resolve(page, locator))) {
            throw new AssertionError("Expected native element to be visible: " + page + "." + locator);
        }
    }

    public void verifyEnabled(String page, String locator) {
        if (!actionPerformer.isEnabled(resolve(page, locator))) {
            throw new AssertionError("Expected native element to be enabled: " + page + "." + locator);
        }
    }

    public void verifySelected(String page, String locator) {
        if (!actionPerformer.isSelected(resolve(page, locator))) {
            throw new AssertionError("Expected native element to be selected: " + page + "." + locator);
        }
    }

    public void verifyTextEquals(String page, String locator, String expected) {
        String actual = actionPerformer.text(resolve(page, locator));
        if (!expected.equals(actual)) {
            throw new AssertionError("Expected native text [" + expected + "] but found [" + actual + "]");
        }
    }

    public void verifyTextContains(String page, String locator, String expected) {
        String actual = actionPerformer.text(resolve(page, locator));
        if (actual == null || !actual.contains(expected)) {
            throw new AssertionError("Expected native text to contain [" + expected + "] but found [" + actual + "]");
        }
    }

    public void verifyAttributeEquals(String page, String locator, String attribute, String expected) {
        String actual = actionPerformer.attribute(resolve(page, locator), attribute);
        if (!expected.equals(actual)) {
            throw new AssertionError("Expected native attribute [" + attribute + "] to be [" + expected + "] but found [" + actual + "]");
        }
    }

    public void verifyAttributeContains(String page, String locator, String attribute, String expected) {
        String actual = actionPerformer.attribute(resolve(page, locator), attribute);
        if (actual == null || !actual.contains(expected)) {
            throw new AssertionError("Expected native attribute [" + attribute + "] to contain [" + expected + "] but found [" + actual + "]");
        }
    }

    public void verifyCount(String page, String locator, int expected) {
        int actual = actionPerformer.count(resolve(page, locator));
        if (actual != expected) {
            throw new AssertionError("Expected native element count [" + expected + "] but found [" + actual + "]");
        }
    }

    public void swipe(String direction) {
        actionPerformer.swipe(direction);
    }

    public void longPress(String page, String locator) {
        actionPerformer.longPress(resolve(page, locator));
    }

    public void dragDrop(String sourcePage, String sourceLocator, String targetPage, String targetLocator) {
        actionPerformer.dragDrop(resolve(sourcePage, sourceLocator), resolve(targetPage, targetLocator));
    }

    public void back() {
        actionPerformer.back();
    }

    public void hideKeyboard() {
        actionPerformer.hideKeyboard();
    }

    public void screenshot(String name) {
        actionPerformer.screenshot(name);
    }

    public void acceptAlert() {
        actionPerformer.acceptAlert();
    }

    public void dismissAlert() {
        actionPerformer.dismissAlert();
    }

    private By resolve(String page, String locator) {
        return locatorHandler.getLocator(page, locator);
    }
}
