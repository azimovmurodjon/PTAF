package com.ptaf.mobile.nativeapp.handlers;

import com.ptaf.utils.YamlReader;
import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;

public class MobileNativeLocatorHandler {

    private static final String ROOT = "mobileNativeElements.";

    public By getLocator(String page, String locatorName) {
        Object configuredLocator = YamlReader.get(ROOT + page + "." + locatorName);
        if (configuredLocator == null) {
            throw new IllegalArgumentException(
                    "Native mobile locator not found: " + ROOT + page + "." + locatorName
            );
        }
        return byToken(String.valueOf(configuredLocator));
    }

    public By byToken(String token) {
        String value = token == null ? "" : token.trim();
        int separator = value.indexOf('_');

        if (separator <= 0) {
            throw new IllegalArgumentException(
                    "Invalid native mobile locator token: " + token
                            + ". Expected format like ACCESSIBILITY_Login, ID_loginButton, or XPATH_//..."
            );
        }

        String type = value.substring(0, separator).trim().toUpperCase();
        String locator = value.substring(separator + 1).trim();

        return switch (type) {
            case "ACCESSIBILITY", "ACCESSIBILITYID", "A11Y" -> AppiumBy.accessibilityId(locator);
            case "ID" -> By.id(locator);
            case "XPATH" -> By.xpath(locator);
            case "CLASS", "CLASSNAME" -> By.className(locator);
            case "ANDROID_UIAUTOMATOR", "UIAUTOMATOR" -> AppiumBy.androidUIAutomator(locator);
            case "IOS_PREDICATE", "PREDICATE" -> AppiumBy.iOSNsPredicateString(locator);
            case "IOS_CLASS_CHAIN", "CLASSCHAIN" -> AppiumBy.iOSClassChain(locator);
            case "TEXT" -> By.xpath("//*[contains(@text,'" + locator + "') or contains(@label,'" + locator
                    + "') or contains(@name,'" + locator + "')]");
            default -> throw new IllegalArgumentException(
                    "Unsupported native mobile locator type: " + type
                            + ". Supported: ACCESSIBILITY, ID, XPATH, CLASS, ANDROID_UIAUTOMATOR, IOS_PREDICATE, IOS_CLASS_CHAIN, TEXT."
            );
        };
    }
}
